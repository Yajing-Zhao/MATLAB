%%
% (a III) 
% The predicted value of u(x) is very close to the ground truth value of
% u(x),
% With the decrease of sampling point space, the error goes down.
% Both one sided second order and centered second order have a log-log line of slope 2. 
% The error of centered second order is smaller compared to one sided
% second order.
%
%
%%
% (b III) 
% The predicted value of u(x) approximates the ground truth very well.
% With the decrease of samping space, the error goes down.
% One sided 4th order approximation has a log-log line of slope 4
% One sided 6th order approximation has a log-log line of slope 6
%
%
%
%%
% (d)
% The p is estimated by the slope of the error log-log plot.
% Also note the log(a/b) = log(a) - log(b).
% 
%
%
%
%
%
%
%
%
%
%
